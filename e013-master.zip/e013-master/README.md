# e013

A little VBScript that steal Wifi passwords from Windows 

Into the file WifiName.txt you can see the password of every saved wifi available on every windows computer that support VBscript 

![](https://i.imgur.com/wxT1Uj2.png)

