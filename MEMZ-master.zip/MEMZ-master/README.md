# MEMZ
A pre-compiled version of MEMZ.EXE, featured on danooct1's YouTube series, Malware Investigations.
